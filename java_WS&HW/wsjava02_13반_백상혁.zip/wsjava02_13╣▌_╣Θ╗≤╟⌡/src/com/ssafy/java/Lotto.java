package com.ssafy.java;

import java.util.Random;

public class Lotto {

	public static void main(String[] args) {
		Random rand = new Random();
		int []lotto = new int[6];
		int num, count=0;
		while(count<6) {
			boolean check = true;
			num = rand.nextInt(45)+1;
			for(int i=0; i<count; ++i) {
				if(lotto[i] != 0 && num == lotto[i]) {
					check = false; 
					break;
				}
			}
			if(check) {
				lotto[count++] = num;
			}
		}
		for (int i = 0; i < lotto.length; i++) {
			System.out.println(lotto[i]);
		}
	}

}
