package com.java.first;

public class CircleArea {
	public static void main(String[] args) {
		int r = 5;
		if(r>=0)
			System.out.printf("반지름이 %dCm인 원의 넓이는 %.2fCm2입니다.",r,r*r*3.14);
		else
			System.out.println("반지름이 0보다 작습니다.");
	}
}
