package com.ssafy.java;

public class AplaTest2 {

	public static void main(String[] args) {
		char alpha = 'A';
		for (int i = 0; i < 5; i++) {
			for (int j = 4; j >= 0; j--) {
				if(j<=i)
					System.out.print(alpha++ + " ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}

}
