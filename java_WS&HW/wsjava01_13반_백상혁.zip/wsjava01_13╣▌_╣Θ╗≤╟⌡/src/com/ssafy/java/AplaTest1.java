package com.ssafy.java;

public class AplaTest1 {

	public static void main(String[] args) {
		char alpha = 'A';
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < i+1; j++) {
				System.out.print(alpha++ + " ");
			}
			System.out.println();
		}
	}
	
}
