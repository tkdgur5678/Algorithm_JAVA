package com.ssafy.java;

public class ArrayTest {

	public static void main(String[] args) {
		int []arr = {34,23,64,25,12,75,22,88,53,37};
		int sum = 0;
		int min = Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];
			min = Integer.min(min, arr[i]);
			System.out.print(arr[i] + " ");
		}
		System.out.println();
		System.out.println("�迭�� �� : "+sum);
		System.out.println("�迭�� ��� : "+sum/arr.length);
		System.out.println("�迭�� �ּҰ� : "+min);
	}

}
