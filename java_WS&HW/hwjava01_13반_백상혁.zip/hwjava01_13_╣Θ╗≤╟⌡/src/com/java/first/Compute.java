package com.java.first;

public class Compute {

	public static void main(String[] args) {
		int num1 = 16;
		int num2 = 5;
		System.out.println("곱="+num1*num2);
		if(num2!=0)
			System.out.println("몫="+num1/num2);
		else
			System.out.println("divide by zero");
	}

}
