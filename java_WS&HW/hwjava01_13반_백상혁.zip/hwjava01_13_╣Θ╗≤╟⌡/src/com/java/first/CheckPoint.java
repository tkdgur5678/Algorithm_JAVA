package com.java.first;

public class CheckPoint {

	public static void main(String[] args) {
		int tall = 155;
		int weight = 60;
		int result = weight+100-tall;
		System.out.println(result);
		if(result>0)
			System.out.println("당신은 비만이군요");
	}

}
